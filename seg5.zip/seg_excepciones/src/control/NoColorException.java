package control;

public class NoColorException extends Exception {



	public NoColorException(String message) {
		super(message);
		
	}

	
	
	

}
