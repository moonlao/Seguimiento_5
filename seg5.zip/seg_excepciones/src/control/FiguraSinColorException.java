package control;

public class FiguraSinColorException extends Exception{

	public FiguraSinColorException(String message) {
		super(message);
		
	}
   
}
